%   Tutorial software for Spacecraft Attitude and Control Control
%
%   This directory contains the companion software for the tutorial
%   chapter in the book, Spacecraft Attitude and Control Control. These
%   scripts have been written to run in MATLAB with no other toolbox 
%   dependencies. 
%
%   For more information, please contact us at info@psatellite.com
%
%-------------------------------------------------------------------------------
%
%   Princeton Satellite Systems
%   6 Market Street, Suite 926
%   Plainsboro, NJ 08536
%   http://www.psatellite.com
%
%-------------------------------------------------------------------------------

